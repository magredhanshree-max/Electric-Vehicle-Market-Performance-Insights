# Electric Vehicle Market Performance & Insights (2026)

A small data-analysis project on the global EV market, covering January to September 2026. It loads sales data from CSV files, computes regional share and growth metrics, and produces charts.

> **Data snapshot:** October 25, 2026. Figures come from public reports (see [Sources](#sources)) and were transcribed by hand. Regional values for September and for the year-to-date are rounded as reported.

## Key findings

| Metric | Value |
|---|---|
| Global EV sales, Sep 2026 | 2.15M (-2% YoY, +17% MoM) |
| Global EV sales, Jan-Sep 2026 | 15.5M (+3% YoY) |
| Global EV sales, full-year 2025 | 20.7M (+20% YoY) |

| Region | Jan-Sep 2026 | YoY | Share |
|---|---|---|---|
| China | 8.1M | -13% | 52% |
| Europe | 3.9M | +30% | 25% |
| Rest of World | 2.3M | +93% | 15% |
| North America | 1.2M | -24% | 8% |

1. **Growth has slowed sharply**, from about 20% in 2025 to about 3% year-to-date in 2026.
2. **Europe set a record in September** with almost 600,000 EVs. Battery-electric sales grew 50% and plug-in hybrids 16%.
3. **China is still the largest market but is shrinking** (-18% YoY in September), pushing carmakers toward exports.
4. **North America fell 44% in September**, largely because of an unusually strong comparison period before US tax credits expired.
5. **Emerging markets are the fastest growing**, with year-to-date sales larger than North America's.
6. **BYD leads Tesla in battery-electric volume.** In Q3 2026 BYD sold 762,478 passenger BEVs against Tesla's 486,532 deliveries. BYD's figure excludes plug-in hybrids.

## Charts

| | |
|---|---|
| ![Regional YTD](charts/regional_ytd_2026.png) | ![YoY growth](charts/yoy_growth_by_region.png) |
| ![Share](charts/regional_share_2026.png) | ![Tesla vs BYD](charts/tesla_vs_byd_q3.png) |

## Project structure

```
ev-market-analysis/
├── analysis.py          # loads data, computes metrics, saves charts
├── data/                # source CSVs (+ computed metrics output)
├── charts/              # generated PNG charts
├── requirements.txt
├── LICENSE
└── README.md
```

## How to run

```bash
git clone https://github.com/<your-username>/ev-market-analysis.git
cd ev-market-analysis
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python analysis.py
```

The script prints a summary to the terminal, saves four charts in `charts/`, and writes `data/regional_metrics_computed.csv`.

## Methodology and limitations

- "EV" means battery-electric plus plug-in hybrid passenger cars and light-duty vehicles, following the data provider's definition.
- Prior-year volumes (`ytd_2025_implied`) are **derived** from reported YoY percentages and rounded, so they are estimates.
- Tesla reports deliveries; BYD figures are passenger BEV sales only. They are not like-for-like with total EV or PHEV volumes.
- Regional figures are rounded as published; the four regions sum to the 15.5M global total.
- This is descriptive analysis, not a forecast, and not financial advice.

## Sources

- Benchmark Mineral Intelligence (incl. Rho Motion), monthly global EV sales report for September 2026, published Oct 16, 2026
- Reuters, Electrek, and EV Infrastructure News coverage of the same report
- Tesla Form 8-K, Q3 2026 production and deliveries
- CnEVPost, Tesla vs BYD quarterly comparison (Oct 2026)

## Ideas for extension

- Add monthly time-series data and plot trends
- Compare BEV vs PHEV split by region
- Add Q4 2026 data when published
- Build an interactive dashboard (Streamlit or Plotly)

## License

MIT, see [LICENSE](LICENSE).
