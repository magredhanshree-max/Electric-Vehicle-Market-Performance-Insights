"""Electric Vehicle Market Performance & Insights (Jan-Sep 2026).

Reads the CSV files in ./data, prints key insights and saves charts to ./charts.
Run:  python analysis.py
"""
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).parent
DATA = ROOT / "data"
CHARTS = ROOT / "charts"
CHARTS.mkdir(exist_ok=True)

COLORS = {"Europe": "#2a9d8f", "China": "#e63946",
          "North America": "#457b9d", "Rest of World": "#f4a261"}


def load():
    regional = pd.read_csv(DATA / "regional_sales_2026.csv")
    q3 = pd.read_csv(DATA / "tesla_vs_byd_q3.csv")
    q2026 = pd.read_csv(DATA / "tesla_byd_2026_quarterly.csv")
    return regional, q3, q2026


def add_metrics(regional: pd.DataFrame) -> pd.DataFrame:
    df = regional.copy()
    total = df["ytd_2026_units"].sum()
    df["ytd_share_pct"] = (df["ytd_2026_units"] / total * 100).round(1)
    # Implied prior-year YTD volume derived from the reported YoY change.
    df["ytd_2025_implied"] = (df["ytd_2026_units"] / (1 + df["ytd_2026_yoy_pct"] / 100)).round(-4)
    df["ytd_change_units"] = df["ytd_2026_units"] - df["ytd_2025_implied"]
    return df


def chart_regional_ytd(df):
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(df["region"], df["ytd_2026_units"] / 1e6,
           color=[COLORS[r] for r in df["region"]])
    for i, (v, g) in enumerate(zip(df["ytd_2026_units"], df["ytd_2026_yoy_pct"])):
        ax.text(i, v / 1e6 + 0.1, f"{v/1e6:.1f}M\n({g:+d}% YoY)", ha="center", fontsize=9)
    ax.set_ylabel("EV sales, Jan-Sep 2026 (million)")
    ax.set_title("EV sales by region, year-to-date 2026")
    ax.set_ylim(0, df["ytd_2026_units"].max() / 1e6 * 1.2)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(CHARTS / "regional_ytd_2026.png", dpi=160)
    plt.close(fig)


def chart_yoy(df):
    fig, ax = plt.subplots(figsize=(8, 5))
    x = range(len(df))
    w = 0.38
    ax.bar([i - w / 2 for i in x], df["sep_2026_yoy_pct"], w, label="September 2026", color="#264653")
    ax.bar([i + w / 2 for i in x], df["ytd_2026_yoy_pct"], w, label="Year-to-date", color="#8ab17d")
    ax.axhline(0, color="black", linewidth=0.8)
    ax.set_xticks(list(x))
    ax.set_xticklabels(df["region"])
    ax.set_ylabel("Year-on-year change (%)")
    ax.set_title("Growth is diverging: Europe & emerging markets up, China & N. America down")
    ax.legend()
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(CHARTS / "yoy_growth_by_region.png", dpi=160)
    plt.close(fig)


def chart_share(df):
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.pie(df["ytd_2026_units"], labels=df["region"], autopct="%1.0f%%", startangle=90,
           colors=[COLORS[r] for r in df["region"]], wedgeprops={"width": 0.45})
    ax.set_title("Share of global EV sales, Jan-Sep 2026")
    fig.tight_layout()
    fig.savefig(CHARTS / "regional_share_2026.png", dpi=160)
    plt.close(fig)


def chart_tesla_byd(q3):
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(q3["year"], q3["tesla_deliveries"] / 1e3, marker="o", label="Tesla deliveries", color="#e63946")
    ax.plot(q3["year"], q3["byd_passenger_bev_sales"] / 1e3, marker="o", label="BYD passenger BEV sales", color="#2a9d8f")
    ax.set_ylabel("Q3 volume (thousand vehicles)")
    ax.set_title("Q3 comparison: Tesla vs BYD (battery-electric)")
    ax.legend()
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(CHARTS / "tesla_vs_byd_q3.png", dpi=160)
    plt.close(fig)


def print_insights(df, q3, q2026):
    total = df["ytd_2026_units"].sum()
    print("=== EV Market Insights (Jan-Sep 2026) ===")
    print(f"Total YTD sales (sum of regions): {total/1e6:.1f}M")
    for _, r in df.iterrows():
        print(f"- {r['region']:<14} {r['ytd_2026_units']/1e6:>4.1f}M  "
              f"share {r['ytd_share_pct']:>4.1f}%  YoY {r['ytd_2026_yoy_pct']:+d}%  "
              f"(~{r['ytd_change_units']/1e6:+.2f}M vs implied 2025)")
    last = q3.iloc[-1]
    gap = last["byd_passenger_bev_sales"] - last["tesla_deliveries"]
    print(f"\nQ3 2026: BYD ahead of Tesla by {gap:,.0f} vehicles "
          f"({gap/last['tesla_deliveries']*100:.1f}%).")
    print("9M 2026 BYD BEV:", f"{q2026['byd_passenger_bev_sales'].sum():,}",
          "| Tesla:", f"{q2026['tesla_deliveries'].sum():,}")


def main():
    regional, q3, q2026 = load()
    df = add_metrics(regional)
    print_insights(df, q3, q2026)
    chart_regional_ytd(df)
    chart_yoy(df)
    chart_share(df)
    chart_tesla_byd(q3)
    df.to_csv(DATA / "regional_metrics_computed.csv", index=False)
    print(f"\nCharts saved to {CHARTS}")


if __name__ == "__main__":
    main()
